## **Neck Guard**
**Layer Modification – All Armor**  
_An armored scarf, gorget, or reinforced collar protecting the neck, jaw, and throat - areas vulnerable to decisive blows._

**Buy & apply cost:** 1/4× the armor’s cost  
**Repair $+** 10%

**<font color="#92d050">Bonuses</font>
- -4 damage to Critical [[Strikes]] against you
**<font color="#c00000">Penalties</font>**
- +1 Reflex Penalty.
- +0.5kg worn weight.

---
## **Winterization**
**Layer Modification – All Armor**  
_Insulated padding, fur lining, or heat-retentive materials integrated to preserve warmth in extreme cold._

**Buy & apply cost:** 1/4× the armor’s cost  
**Repair $+** 10%

**<font color="#92d050">Bonuses</font>**
- +3 [[2.1 Armor Overview|Armor Rating]] against [[2.1 Damage & Resistance|Cold Damage]].
- Treat **ambient cold** as **one step less severe**.
- +[[2.2 Armor Traits|{Comfortable}]] if the armor is not [[2.2 Armor Traits|{Inflexible}]] or [[2.1 Armor Overview|Heavy Armor]].
**<font color="#c00000">Penalties</font>**
- [[2.2 Armor Traits|{Stuffy}]] +1
- Treat **ambient heat** as **one step more severe**.

---
## **Rubberized Weave**
**Layer Modification – All Armor**  
_Shock-absorbing rubberized fibers woven into or beneath the armor to insulate against electrical discharge._

**Buy & apply cost:** 1/3× the armor’s cost  
**Repair $+** 50%

**<font color="#92d050">Bonuses</font>**
- +4 [[2.1 Armor Overview|Armor Rating]] against [[2.1 Damage & Resistance|Electricity Damage]].
**<font color="#c00000">Penalties</font>**
- - [[2.2 Armor Traits|{Hushed}]]
- +1kg worn weight
- [[2.2 Armor Traits|{Stuffy}]] +1

---
## **Sport Layer**
**Layer Modification – All Armor**  
_Linen, wool, or treated fiber underlayers designed to pull sweat away from the body and reduce heat buildup during exertion._

**Buy & apply cost:** 1/4× the armor’s cost  
**Repair $+** 10%

**<font color="#92d050">Bonuses</font>**
- Reduce the armor’s **[[2.2 Armor Traits|{Stuffy}]]** value by **1**.

---
## **Comfort Lining**
**Layer Modification – All Armor**  
_Padded, articulated internal lining that reduces psychological strain and the feeling of confinement._

**Buy & apply cost:** 1/4× the armor’s cost  
**Repair $+** 20%

**<font color="#92d050">Bonuses</font>**
- [[2.2 Armor Traits|{Claustrophobic}]] -1
	- If this reduces the trait to 0 or the armor doesn't have the trait, then + [[2.2 Armor Traits|{Comfortable}]].
**<font color="#c00000">Penalties</font>**
- [[2.2 Armor Traits|{Stuffy}]] +1

---
## **Silk Lining**
**Layer Modification – Light & Medium Armor**  
_Fine silk or silk-blend layers that resist tearing and catch penetrating edges, reducing precision lethality at the cost of heat retention._

**Buy & apply cost:** 1/4× the armor’s cost  
**Repair $+** 30%

**<font color="#92d050">Bonuses</font>**
- Ignore **one instance of [[1.3 Advantage & Disadvantage|Disadvantage]]** imposed by armor on **[[Finesse|Sneak]]** checks.
- Reduce Precision and Bleed damage taken by 2.
**<font color="#c00000">Penalties</font>**
- [[2.2 Armor Traits|{Stuffy}]] +1

---
## **Emergency Padding**
**Layer Modification – All Armor**  
_Thick, sacrificial padding intended to absorb sudden concussive force, often worn only when extreme danger is expected._

**Buy & apply cost:** 1/5× the armor’s cost  
**Repair $+** 30%

**<font color="#92d050">Bonuses</font>**
- + [[2.2 Armor Traits|{Shock Absorbing}]] (1, 2)
	- If armor already has [[2.2 Armor Traits|{Shock Absorbing}]], increase its Y by 2.
**<font color="#c00000">Penalties</font>**
- + [[2.2 Armor Traits|{Cumbersome}]]
- +2kg worn weight

---
## **Quilted Mantle**
**Layer Modification – All Armor**  
_A thick padded over-garment worn atop armor to diffuse incoming heat, cold, or electricity.

**Buy & apply cost:** 1/3× the armor’s cost  
**Repair $+** 30%

**<font color="#92d050">Bonuses</font>**
- +2 Energy [[2.1 Armor Overview|Armor Rating]]
- +2 [[2.1 Armor Overview|Armor Rating]] against [[2.1 Damage & Resistance|Acid Damage]]
**<font color="#c00000">Penalties</font>**
- [[2.2 Armor Traits|{Stuffy}]] +2