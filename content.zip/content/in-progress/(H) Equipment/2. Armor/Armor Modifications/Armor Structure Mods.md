---
aliases:
  - Reinforced Joinings
  - Quick-Release Segments
  - Shear Armor
  - Load-Bearing Frame
  - Assault-Articulated Harness
  - Ultra-Light Undercoat
  - Critical Cage
---
# **Reinforced Joinings**
_Structural Modification - All Armor_
_Extra armoring placed around sensitive joints and points of articulation, trading flexibility and subtlety for raw structural integrity._

**Buy & apply cost:** 0.3x the armor’s cost  
**Repair $+** 10%

**<font color="#92d050">Bonuses</font>**
- +1 to two [[2.1 Armor Overview|Armor Rating]]s of your choice
- Increase the armor’s **maximum Durability by 1 level** (Max 1d12).
**<font color="#c00000">Penalties</font>**
- + [[2.2 Armor Traits|{Inflexible}]]
	- If the armor already has that trait, instead increase its **Reflex Penalty by 1**.
- - [[2.2 Armor Traits|{Hushed}]].

---
# **Quick-Release Segments**
_Structural Modification – Medium & Heavy Armor_  
_Armor plates or sections designed to shear away under extreme force, allowing the wearer to sacrifice structure to survive the blow._

**Buy & apply cost:** 0.7x the armor’s cost  
**Repair $+** 40%

**<font color="#92d050">Bonuses</font>**
- Reduce the armor’s **don/doff time by half** (minimum 1 action).
- Gain the **Shear Armor** reaction.
**<font color="#c00000">Penalties</font>**
- Reduce the armor’s **maximum Durability by 1 level**.
### **Shear Armor (↻)**
**Cost:** 2 Focus; reduce armor Durability by 1  
**Trigger:** You suffer [[2.1 Damage & Resistance|Material Damage]]  
**Effect:** Reduce that damage by **8**. Suffer **[[1.3 Advantage & Disadvantage|Disadvantage]]** on all [[1.1 Skill Checks|Skill Checks]] until the end of your next Turn.

---
# **Load-Bearing Frame**
_Structural Modification – All Armor_  
_Custom straps, redistributed weight paths, and reinforced rigging designed for endurance over long campaigns._

**Buy & apply cost:** 0.4x the armor’s cost  
**Repair $+** 30%

**<font color="#92d050">Bonuses</font>**
- Reduce the armor’s **Worn Weight by 4 kg or by half (whichever is greater)**.
- - [[2.2 Armor Traits|{Cumbersome}]]
**<font color="#c00000">Penalties</font>**
- +2kg Carried Weight

---
## **Assault-Articulated Harness**
_Structural Modification – Medium & Heavy Armor_  
_Reworked joints and segmented plating prioritize motion and responsiveness at the cost of continuous protection._

**Buy & apply cost:** 0.8x the armor’s cost  
**Repair $+** 50%

**<font color="#92d050">Bonuses</font>**
- Reflex Penalty -2
- - [[2.2 Armor Traits|{Inflexible}]]
- Ignore any **[[1.2 Initiative|Initiative]] penalty** imposed by the armor.
**<font color="#c00000">Penalties</font>**
- -3 [[2.1 Damage & Resistance|Blade Damage]], [[2.1 Damage & Resistance|Blunt Damage]], or [[2.1 Damage & Resistance|Ballistic Damage]] [[2.1 Armor Overview|Armor Rating]].
---
## **Ultra-Light Undercoat**
_Structural Modification – All Armor_  
_Internal restructuring and lightweight materials emphasize airflow and comfort over cushioning._

**Buy & apply cost:** 0.4x the armor’s cost  
**Repair $+** 30%

**<font color="#92d050">Bonuses</font>**
- [[2.2 Armor Traits|{Stuffy}]] -2
- [[2.2 Armor Traits|{Claustrophobic}]] -1
- + [[2.2 Armor Traits|{Breathable}]]
**<font color="#c00000">Penalties</font>**
- -2 [[2.1 Damage & Resistance|Blunt Damage]] [[2.1 Armor Overview|Armor Rating]]
- [[2.2 Armor Traits|{Bulwark}]] -1
---
## **Critical Cage**
_Structural Modification – Medium & Heavy Armor_  
_An internal load-bearing skeleton transforms the armor into a rigid survival shell, hostile to movement but brutally resilient._

**Buy & apply cost:** 0.9x the armor’s cost  
**Repair $+** 40%

**<font color="#92d050">Bonuses</font>**
- + [[2.2 Armor Traits|{Hard Frame}]].
    - If the armor already has that trait, instead +1 to three **[[2.1 Armor Overview|Armor Rating]]s** of your choice.
**<font color="#c00000">Penalties</font>**
- + [[2.2 Armor Traits|{Inflexible}]]
    - If it already had that trait, [[2.2 Armor Traits|{Stuffy}]] +2 instead.
- + [[2.2 Armor Traits|{Cumbersome}]]
    - If it already had that trait, **[[2.2 Armor Traits|{Claustrophobic}]]** +2 instead.