## **Storage**

**Accessory Modification**

Pouches, loops, hidden pockets, or integrated containers.

- Increase the wearer’s **effective carry capacity by a small amount** (GM discretion; typically +2–5 kg).
    
- Increase the armor’s **Carried Weight by 1–2 kg**.
    

_Purpose:_ Practical utility without combat impact.


## **Spiked Gauntlets**

**Accessory Modification**

Spurs, studs, or spikes mounted to the gauntlets.

- Unarmed strikes made with your hands gain **+1 damage**.
    
- You gain **Advantage** on checks made to **maintain a Grapple**.
    
- Increase the armor’s **Noisy value by 2** (or gain {Noisy} if it did not have it).
    

_Purpose:_ Making close contact dangerous.

---

## **Weighted Gauntlets**

**Accessory Modification**

Dense reinforcement or weighted inserts in the gauntlets.

- Unarmed strikes made with your hands gain **+1 Blunt damage**.
    
- Increase **Physical Stress** suffered when performing unarmed attacks by **1**.
    

_Purpose:_ Heavier hits at a stamina cost.