## **Lacquering**

**Coating Modification**

A protective chemical sealant that resists corrosion and decay.

- Increase the armor’s **maximum Durability by 1 level**.
    
- Increase the armor’s **Acid Armor Rating by 3**.
    
- Repairs to this armor take **twice as long** and **cost twice as much**.
    

_Purpose:_ Longevity and corrosion resistance with logistical downsides.


## **Fireproofing**

**Coating Modification**

Fire-resistant treatments layered over or infused into the armor.

- Increase the armor’s **maximum Durability by 1 level**.
    
- Increase the armor’s **Fire / Energy Armor Rating by 3**.
    
- When the armor suffers **Fire damage**, it does not trigger additional Durability checks unless the damage is Critical.
    

_Purpose:_ Survival in flame-heavy environments without blanket elemental immunity.

Blunting