---
aliases:
  - Upgrade Action
  - Daring Footwork
  - Daring Deflection
  - Daring Response
  - Dare Against Doom
  - Daring Bravery
  - Dramatic Reversal
---
# Upgrade Action (✧)
<font color="#d83931">Cost:</font> **2 [[1.7 Force of Will|Force of Will]]**  
<font color="#d83931">Trigger:</font> You are about to take a [[1.3 Actions|Minor ⋄ Action]] that has a [[1.3 Actions|Major ⟐ Action]] version.
<font color="#d83931">Effect:</font> The action is immediately treated as its Major version, gaining all ⟐ benefits and effects.
# Daring Footwork (✧)
<font color="#d83931">Cost:</font> **1 [[5. Triumphs & The Daring|Daring]]**  
<font color="#d83931">Frequency:</font> **Once per turn**
<font color="#d83931">Effect:</font> You [[Movement Actions|Step]] up to 5ft. as a [[1.3 Actions|Free ✧ Action]]. This move does not count against your normal movement limits.  
# Daring Response (↻)
<font color="#d83931">Cost:</font> **4 Daring**  
<font color="#d83931">Trigger:</font> A creature declares, begins, or ends an [[1.3 Actions|Action]], or a creature's [[1.1 Encounters|Turn]] ends or begins.
<font color="#d83931">Effect:</font> You may take a non-[[Strikes|Strike]] [[1.3 Actions|Minor ⋄ Action]] as if it were a [[1.3 Actions|Reaction ↻]]. You must still meet all prerequisites for that action.  



Can youse two Force of Will to INVERT the effects of [[3.3 Mortal Peril|Peril]] for the purposes of one skill check or defense per round,  but suffer a penalty of some kind