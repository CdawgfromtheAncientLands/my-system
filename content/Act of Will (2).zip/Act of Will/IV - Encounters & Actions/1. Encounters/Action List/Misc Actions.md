---
aliases:
  - Help
  - Change Grip
  - Interact
  - Grab an Edge
  - Finger
  - Administer First Aid
  - Toss
  - Sustain
---
# Help (⋄)
Requirements: You must be able to meaningfully assist the other creature’s attempt.
Effect: Describe how you assist another creature ("I encourage them" isn't enough). Propose a Skill relevant to the assistance. The GM approves the Skill and sets the Action’s traits and cost (usually a Minor action).
Roll the chosen **Skill** versus an appropriate **DC** determined by the GM.
- **Crit Success**. As Success, but [[1.3 Advantage & Disadvantage|Advantage]] instead.
- **Success.** You meaningfully assist them: they gain +1 to their next [[1.1 Skill Checks|Skill Check]] that contributes toward whatever you helped them with.
- **Crit Fail.** As success but you hinder the ally; they suffer **-1** instead.

**Limits & Notes:** Help cannot be used when the fiction makes assistance impossible (too far away, restrained, unaware, or unable to meaningfully contribute). Different types of Help may have additional traits (Manipulate, Mental, Auditory, etc.).
# Change Grip (⋄)
[[Action & Effect Traits|{Manipulate}]]
Requirements: You must be holding something.
Effect: You shift your grip on an item you’re holding - changing hands, adjusting leverage, or reducing the number of hands committed to it. If you use this to release an item, it is a [[1.3 Actions|Free ✧ Action]] and the item will fall into your space.
# Sustain (⋄)
[[Action & Effect Traits|{Concentrate}]]
Effect: You sustain a continuous effect. This action's traits may change depending on the effect.
# Interact (⋄)
[[Action & Effect Traits|{Manipulate}]], [[Action & Effect Traits|{Precise}]], [[Action & Effect Traits|{Melee}]]
Requirements: You have at least one free hand.
Effect: You handle, manipulate, or operate something physically—an object, tool, mechanism, or part of the environment. Common uses include: 
- retrieving or stowing an item, 
- drawing a weapon, 
- opening a door, 
- swapping one held item for another, 
- or manipulating anything small or tactile.

**Limits:** Interact cannot replace the effects of specialized actions (e.g., Disable, Steal, Administer First Aid).  
If interacting with a held or guarded object, you will make skill checks at GM discretion.
# Grab an Edge (↻)
[[Action & Effect Traits|{Concentrate}]], [[Action & Effect Traits|{Move}]]
Trigger: You would fall past an edge, handhold, or other ledge capable of supporting a grip.
Requirements: You have at least one usable arm.
Effect: Attempt to grab the edge by rolling [[Athletics|Acrobatics]] or **[[1.2 Disciplines & Skills|Reflex]]** versus a DC set by the fall height and surface.
- **Crit Success.** You catch the edge cleanly and stop your fall. No hand is required to remain free afterward.
- **Success.** You grab the edge and stop your fall. You take fall damage as if the fall were **20 ft shorter** than the distance fallen before grabbing.
- **Crit Fail.** You fumble and strike the ledge, taking **half** the fall damage you would have taken had you hit the ground

**Limits:** Pulling yourself onto stable ground is a [[Movement Actions|Climb]] action unless the GM rules otherwise.
# Finger (⋄)
[[Action & Effect Traits|{Auditory}]], [[Action & Effect Traits|{Visual}]]
Effect: You subtly call attention to a creature that is not [[2.1 Reading a Condition|Unnoticed]] to you. Any creature that can see or hear you increases its [[2.4 Detection Rating]] of the pointed-out target by **1**, but cannot exceed your own [[2.4 Detection Rating]] of that creature.
# Administer First Aid (⟐)
[[Action & Effect Traits|{Concentrate}]], [[Action & Effect Traits|{Interact}]], [[Action & Effect Traits|{R.A.P.}]]
Requirements: You are equipped with a First Aid Kit and have an [[Open Hand]] to use it - OR you are currently wielding said kit.
Effect: Perform emergency medical treatment. Make a [[Medicine|First Aid]] check, DC 16. Choose **Stabilize** or **Emergency Care** - these count as [[1.3 Actions|Rider ※]]s on [[Misc Actions|Administer First Aid]].

| Strict Outcome | Stabilize                                                                                                                         | Emergency Care                                                                                                                                                        |
| -------------- | --------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Crit Success   | As Success, but 1 hour and the [[3.3 Mortal Peril\|Heal Period]] of the related [[3.3 Mortal Peril\|Injury]] is halved.     | As Success, but they automatically succeed the check.                                                                                                                 |
| Success        | Your patient stops [[3.3 Mortal Peril\|Dying]] and regains consciousness in 1d4 hours.                                         | If your check beats the DC for a poison affecting the patient, remove the poison. If not, they may make a check against a Poison or Persistent Damage affecting them. |
| Crit Fail      | As success, but 2d4 hours and the [[3.3 Mortal Peril\|Heal Period]] of the related [[3.3 Mortal Peril\|Injury]] is doubled. | As success, but the patient takes damage from said poison or persistent damage.                                                                                       |
# Toss an Item (⋄/⟐)
[[Action & Effect Traits|{Precise}]], [[Action & Effect Traits|{R.A.P.}]]
Requirements: You are holding an item you can actually throw.

| Object Weight                                      | [[1.3 Ranged Weapons\|Range Increment]] | Control    |
| -------------------------------------------------- | --------------------------------------- | ---------- |
| ≤ 1/10 [[1.4 Secondary Attribute\|Carry Capacity]] | 20 ft                                   | Controlled |
| ≤ 1/5 [[1.4 Secondary Attribute\|Carry Capacity]]  | 15 ft                                   | Awkward    |
| ≤ 1/2 [[1.4 Secondary Attribute\|Carry Capacity]]  | 10 ft                                   | Heaving    |
Anything heavier:
- Requires two hands
- Always requires a [[1.3 Actions|Major ⟐ Action]] toss

Effect (⋄): You throw an object - select a 5x5ft area within 6 [[1.3 Ranged Weapons|Range Increment]]s to throw it at. That is your "target". Roll [[Shooting|Throwing]] as if you were making a [[Shooting]] [[Strikes|Strike]] against said target. The base DC is 14 - affected by [[5. Weather Effects|Wind]] and [[3. Cover|Cover]] as projectiles.
- **Crit Success.** The item lands where intended, and cannot be damaged, spill, or trigger (or anything similar) accidentally as a result of the throw - it's a perfect landing!
- **Success.** The item lands where intended.
- **Fail.** The item lands in a random direction 1d2x5 (Controlled), 1d4x5 (Awkward), or 1d6 (Heaving) feet away. Objects larger than that hit the ground halfway through the throw.
- **Crit Fail.** As Fail, but the item may be damaged or entirely broken - or the throw may impact something on the way - or may catastrophically misfire. GM determines randomly with deference to the current fictional context.

Effect (⟐): Ignore penalties from [[3. Cover|Cover]] that would affect the throw, increase range by 5ft, and do not suffer the [[1.1 Skill Checks|Crit Fail]] effects.